﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado; //criação de variáveis globais >> serão utilizadas em todo o código

        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validating(object sender, CancelEventArgs e) // 
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida!");
                //e.Cancel = true; // o usuário fica "preso", só pode sair se colocar certo (cancela o evento)
            }
            else if (altura <=0) // se o primeiro dá certo, ele só continua;
            {
                MessageBox.Show("Altura deve ser maior que zero");
                //e.Cancel = true;
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || 
                !Double.TryParse(txtAltura.Text, out altura) || 
                raio <=0 || altura <=0)
                {
                     MessageBox.Show("Números inválidos");
                     txtRaio.Focus(); // forma de validar e conseguir sair a qualquer momento
                }

            else
            {
                resultado = Math.PI * Math.Pow(raio, 2) * altura; //math.pi= usa o valor inteiro de pi | pow= potência
                txtResultado.Text = resultado.ToString("N2"); // o resultado DEVE ser transformado em string (entrada e saída são SEMPRE string) >> n2= duas casas depois da vírgula
            }
        }
           

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
     
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close(); //fecha o formulário 
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = string.Empty;
            txtResultado.Clear();
            //formas de limpar os campos

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void txtRaio_Validated(object sender, EventArgs e) // propriedades>> raiozinho>> "validated" > 2 clicks (validated = pessoa preenche o campo e dá o tab, mas se não der certo ela tem que voltar)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)) // se não conseguir converter o texto (string) para double (para fazer o cálculo), então:
            {
                MessageBox.Show("Raio inválido!");
               // txtRaio.Focus(); // o usuário está indo pra outro componente mas é obrigado a voltar
            }
            else if (raio <= 0)
            {
                MessageBox.Show("O raio deve ser maior que zero");
               // txtRaio.Focus();
            }

        }
    }
}
