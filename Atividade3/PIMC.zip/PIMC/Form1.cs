﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        Double peso, altura, IMC;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Valor inválido");
                e.Cancel = true;
            }

            else if (peso <= 0)
            {
                MessageBox.Show("O peso deve ser maior que zero");
                e.Cancel = true;
            }
        }

        private void mskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Valor inválido");
                e.Cancel = true;
            }

            else if (altura <= 0)
            {
                MessageBox.Show("A altura deve ser maior que zero");
                e.Cancel = true;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) ||
                !Double.TryParse(mskbxAltura.Text, out altura) ||
                peso <= 0 || altura <= 0)
            {
                MessageBox.Show("Valores inválidos");
                mskbxPeso.Focus();
            }

            else
            {
                IMC = peso / Math.Pow(altura, 2);
                txtIMC.Text = IMC.ToString("N1"); // ou IMC=math.Round(Imc.1)

                if (IMC < 18.5)
                    MessageBox.Show("Magreza");
                if (IMC >= 18.5 && IMC <= 24.9)
                    MessageBox.Show("Normal");
                if (IMC >= 25.0 && IMC <= 29.9)
                    MessageBox.Show("Sobrepeso");
                if (IMC >= 30.0 && IMC <= 39.9)
                    MessageBox.Show("Obesidade");
                if (IMC > 40.0)
                    MessageBox.Show("Obesidade Grave");
            }

        }
    }
}
