﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if ((A>Math.Abs(B-C) && A<B+C)|| 
                (B> Math.Abs(A-C) && B<A+C) ||
                (C>Math.Abs(A-B) && C < A + B))
            {
                MessageBox.Show("É triângulo");

                if (A == B || A == C || B == A)
                {
                    if ((A == B) && (A == C) && (B==C))
                    {
                        MessageBox.Show("Tipo: Equilátero");
                    }
                    else
                    {
                        MessageBox.Show("Tipo: Isósceles");
                    }
                }
                else
                {
                    MessageBox.Show("Tipo:Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é triângulo");
            }
        }

        private void btnSair_Click(object sender, EventArgs e) => Close();
        private void txtA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtA.Text, out A) ||
                A <= 0) 
            {
                MessageBox.Show("Valor inválido");
                e.Cancel= true; // validatING >> seria focus se fosse validatED
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void txtB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtB.Text, out B) ||
                B <= 0)
            {
                MessageBox.Show("Valor inválido");
                e.Cancel = true;
            }
        }

        private void txtC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtC.Text, out C) ||
                C <= 0)
            {
                MessageBox.Show("Valor inválido");
                e.Cancel = true;
            }
        }
    }
}
