﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnGerarAleatorio_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if ((!int.TryParse(txtNumero1.Text, out numero1)) || (!int.TryParse(txtNumero2.Text, out numero2)) || (numero1 < 0) || (numero2 < 0) || (numero2 <= numero1))
            {
                MessageBox.Show("Número inválido");
                txtNumero1.Focus();
            }
            else
            {
                Random objAlet = new Random();
                double sorteado = objAlet.Next(numero1, numero2);
                MessageBox.Show("Número sorteado = " + sorteado);
            }
        }
    }
}
