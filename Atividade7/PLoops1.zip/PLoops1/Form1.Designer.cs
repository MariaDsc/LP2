﻿namespace PLoops1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsEx1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsEx2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsEx3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsEx4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsSair = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsEx1,
            this.tsEx2,
            this.tsEx3,
            this.tsEx4,
            this.tsSair});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsEx1
            // 
            this.tsEx1.Name = "tsEx1";
            this.tsEx1.Size = new System.Drawing.Size(94, 24);
            this.tsEx1.Text = "Exercício &1";
            this.tsEx1.Click += new System.EventHandler(this.tsEx1_Click);
            // 
            // tsEx2
            // 
            this.tsEx2.Name = "tsEx2";
            this.tsEx2.Size = new System.Drawing.Size(94, 24);
            this.tsEx2.Text = "Exercício &2";
            this.tsEx2.Click += new System.EventHandler(this.tsEx2_Click);
            // 
            // tsEx3
            // 
            this.tsEx3.Name = "tsEx3";
            this.tsEx3.Size = new System.Drawing.Size(94, 24);
            this.tsEx3.Text = "Exercício &3";
            this.tsEx3.Click += new System.EventHandler(this.tsEx3_Click);
            // 
            // tsEx4
            // 
            this.tsEx4.Name = "tsEx4";
            this.tsEx4.Size = new System.Drawing.Size(94, 24);
            this.tsEx4.Text = "Exercício &4";
            this.tsEx4.Click += new System.EventHandler(this.tsEx4_Click);
            // 
            // tsSair
            // 
            this.tsSair.Name = "tsSair";
            this.tsSair.Size = new System.Drawing.Size(48, 24);
            this.tsSair.Text = "&Sair";
            this.tsSair.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsEx1;
        private System.Windows.Forms.ToolStripMenuItem tsEx2;
        private System.Windows.Forms.ToolStripMenuItem tsEx3;
        private System.Windows.Forms.ToolStripMenuItem tsEx4;
        private System.Windows.Forms.ToolStripMenuItem tsSair;
    }
}

