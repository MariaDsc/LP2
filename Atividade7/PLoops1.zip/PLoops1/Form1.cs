﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tsEx1_Click(object sender, EventArgs e)
        {
            {
                if (Application.OpenForms.OfType<frmEx1>().Count() > 0)
                {
                    MessageBox.Show("Form já existe");
                    Application.OpenForms["frmEx1"].Activate();
                }
                else
                {
                    frmEx1 obj1 = new frmEx1();
                    obj1.MdiParent = this;
                    obj1.WindowState = FormWindowState.Maximized;
                    obj1.Show();
                }
            }
        }

        private void tsEx2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmEx2"].Activate();
            }
            else
            {
                frmEx2 obj2 = new frmEx2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void tsEx3_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx3>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmEx3"].Activate();
            }
            else
            {
                frmEx3 obj3 = new frmEx3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void tsEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmEx4"].Activate();
            }
            else
            {
                frmEx4 obj4 = new frmEx4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }
    }
}
