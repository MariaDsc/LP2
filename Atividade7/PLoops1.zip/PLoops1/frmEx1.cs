﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops1
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int qtdeEspacoBranco = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (Char.IsWhiteSpace(c))
                {
                    qtdeEspacoBranco++;
                }
            }
            if (qtdeEspacoBranco != 0)
                MessageBox.Show($"Quantidade de espaços em branco: {qtdeEspacoBranco}");
            else
                MessageBox.Show("Não há espaços em branco");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int qtdeR = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (c == 'r' ||
                    c == 'R')
                {
                    qtdeR++;
                }
            }
            if (qtdeR != 0)
                MessageBox.Show($"Quantidade de letras R: {qtdeR}");
            else
                MessageBox.Show("Não há ocorrência de letra R na frase");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.ToUpper();
            char[] c = frase.ToCharArray();
            int qtdePares = 0;
            int i = 1;

            while (i < frase.Length)
            {
                if (c[i] == c[i - 1] && !char.IsWhiteSpace(c[i]))
                    qtdePares++;
                i++;
            }
            MessageBox.Show($"Há {qtdePares.ToString()} pares de letras");
        }
    }
}
