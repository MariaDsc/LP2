﻿namespace PLoops1
{
    partial class frmEx2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtN = new System.Windows.Forms.TextBox();
            this.lblN = new System.Windows.Forms.Label();
            this.btnGerarH = new System.Windows.Forms.Button();
            this.txtH = new System.Windows.Forms.TextBox();
            this.lblH = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(190, 116);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(401, 22);
            this.txtN.TabIndex = 0;
            this.txtN.TextChanged += new System.EventHandler(this.txtN_TextChanged);
            // 
            // lblN
            // 
            this.lblN.AutoSize = true;
            this.lblN.Location = new System.Drawing.Point(191, 97);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(114, 16);
            this.lblN.TabIndex = 1;
            this.lblN.Text = "Digite um número:";
            // 
            // btnGerarH
            // 
            this.btnGerarH.Location = new System.Drawing.Point(302, 293);
            this.btnGerarH.Name = "btnGerarH";
            this.btnGerarH.Size = new System.Drawing.Size(186, 82);
            this.btnGerarH.TabIndex = 2;
            this.btnGerarH.Text = "Gerar número";
            this.btnGerarH.UseVisualStyleBackColor = true;
            this.btnGerarH.Click += new System.EventHandler(this.btnGerarH_Click);
            // 
            // txtH
            // 
            this.txtH.Enabled = false;
            this.txtH.Location = new System.Drawing.Point(190, 187);
            this.txtH.Name = "txtH";
            this.txtH.Size = new System.Drawing.Size(397, 22);
            this.txtH.TabIndex = 3;
            // 
            // lblH
            // 
            this.lblH.AutoSize = true;
            this.lblH.Location = new System.Drawing.Point(191, 168);
            this.lblH.Name = "lblH";
            this.lblH.Size = new System.Drawing.Size(72, 16);
            this.lblH.TabIndex = 4;
            this.lblH.Text = "Resultado:";
            // 
            // frmEx2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblH);
            this.Controls.Add(this.txtH);
            this.Controls.Add(this.btnGerarH);
            this.Controls.Add(this.lblN);
            this.Controls.Add(this.txtN);
            this.Name = "frmEx2";
            this.Text = "frmEx2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.Button btnGerarH;
        private System.Windows.Forms.TextBox txtH;
        private System.Windows.Forms.Label lblH;
    }
}