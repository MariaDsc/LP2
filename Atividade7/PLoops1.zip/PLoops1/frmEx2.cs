﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops1
{
    public partial class frmEx2 : Form
    {
        public frmEx2()
        {
            InitializeComponent();
        }

        private void txtN_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            double N, H = 0;
            int i;

            if (!double.TryParse(txtN.Text, out N) ||
                N < 0)
            {
                MessageBox.Show("Número inválido");
                txtN.Focus();
            }
            else
            {
                for (i = 0; i < N + 1; i++)
                {
                    H += 1 / N;
                }

            }
            txtH.Text = H.ToString();
        }
    }
}
