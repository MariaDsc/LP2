﻿namespace PLoops1
{
    partial class frmEx3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInverso = new System.Windows.Forms.Label();
            this.txtInverso = new System.Windows.Forms.TextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.txtFrase = new System.Windows.Forms.TextBox();
            this.btnInverte = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInverso
            // 
            this.lblInverso.AutoSize = true;
            this.lblInverso.Location = new System.Drawing.Point(199, 188);
            this.lblInverso.Name = "lblInverso";
            this.lblInverso.Size = new System.Drawing.Size(72, 16);
            this.lblInverso.TabIndex = 8;
            this.lblInverso.Text = "Resultado:";
            // 
            // txtInverso
            // 
            this.txtInverso.Enabled = false;
            this.txtInverso.Location = new System.Drawing.Point(198, 207);
            this.txtInverso.Name = "txtInverso";
            this.txtInverso.Size = new System.Drawing.Size(397, 22);
            this.txtInverso.TabIndex = 7;
            this.txtInverso.TextChanged += new System.EventHandler(this.txtInverso_TextChanged);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(199, 117);
            this.lblFrase.MaximumSize = new System.Drawing.Size(0, 50);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(107, 16);
            this.lblFrase.TabIndex = 6;
            this.lblFrase.Text = "Digite uma frase:";
            // 
            // txtFrase
            // 
            this.txtFrase.Location = new System.Drawing.Point(198, 136);
            this.txtFrase.MaxLength = 50;
            this.txtFrase.Name = "txtFrase";
            this.txtFrase.Size = new System.Drawing.Size(401, 22);
            this.txtFrase.TabIndex = 5;
            this.txtFrase.TextChanged += new System.EventHandler(this.txtFrase_TextChanged);
            // 
            // btnInverte
            // 
            this.btnInverte.Location = new System.Drawing.Point(307, 289);
            this.btnInverte.Name = "btnInverte";
            this.btnInverte.Size = new System.Drawing.Size(191, 82);
            this.btnInverte.TabIndex = 9;
            this.btnInverte.Text = "Inverter";
            this.btnInverte.UseVisualStyleBackColor = true;
            this.btnInverte.Click += new System.EventHandler(this.btnInverte_Click);
            // 
            // frmEx3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 445);
            this.Controls.Add(this.btnInverte);
            this.Controls.Add(this.lblInverso);
            this.Controls.Add(this.txtInverso);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.txtFrase);
            this.Name = "frmEx3";
            this.Text = "frmEx3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInverso;
        private System.Windows.Forms.TextBox txtInverso;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.TextBox txtFrase;
        private System.Windows.Forms.Button btnInverte;
    }
}