﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace PLoops1
{
    public partial class frmEx3 : Form
    {
        public frmEx3()
        {
            InitializeComponent();
        }
        private void txtInverso_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInverte_Click(object sender, EventArgs e)
        {
            int i, j = 0;
            char[] arrayAux = new char[txtFrase.Text.Length];  // Inicializar array com o mesmo tamanho da string original
            var arrayText = txtFrase.Text.Normalize(NormalizationForm.FormD).ToCharArray(); // string text normalizada usando o método Normalize com a forma FormD>> decompõe os caracteres acentuados em letra + acento ( "á" vira "a","´")

            for (i = 0; i < arrayText.Length; i++) // i < tam da cadeia de caracteres + acento
            {
                // Verificar se não é acento nem espaço
                if (CharUnicodeInfo.GetUnicodeCategory(arrayText[i]) != UnicodeCategory.NonSpacingMark && // string text normalizada usando o método Normalize com a forma FormD>> decompõe os caracteres acentuados em letra + acento ( "á" vira "a","´")
                    !char.IsWhiteSpace(arrayText[i])) 
                {
                    arrayAux[j] = arrayText[i];
                    j++;
                }
            }

            string texto = new string(arrayAux.Take(j).Reverse().ToArray()); //Inverte e vai ate o indice j
            string originalSemAcentosEspacos = new string(arrayAux.Take(j).ToArray());

            txtInverso.Text = texto.ToLower(); // Mostra a string invertida e minuscula

            if (String.Compare(originalSemAcentosEspacos.ToUpper(), texto.ToUpper(), StringComparison.OrdinalIgnoreCase) == 0) // Comparar o texto original (em maiúsculas) com o texto invertido
            {
                MessageBox.Show("É palíndromo");
            }
            else
            {
                MessageBox.Show("Não é palíndromo");
            }
        }
    }


}
