﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops1
{
    public partial class frmEx4 : Form
    {
        double salario, producao, gratific, salBruto;

        public frmEx4()
        {
            InitializeComponent();
        }

        private void txtSalario_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Salário inválido");
                e.Cancel = true;
            }
            else if (salario <= 0)
            {
                MessageBox.Show("Salário deve ser maior que 0");
                e.Cancel = true;
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out gratific)) 
            {
                MessageBox.Show("Gratificação inválida");
                txtGratificacao.Focus();
            }

            else if (gratific < 0)
            {
                MessageBox.Show("Gratificação não pode ser negativa");
                txtGratificacao.Focus();
            }
        }

        private void frmEx4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int B, C, D;

            if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            else if (producao >= 120)
            {
                B = 1;
                C = 1;
                D = 0;
            }
            else if (producao >= 100)
            {
                B = 1;
                C = 0;
                D = 0;
            }
            else
            {
                B = 0;
                C = 0;
                D = 0;
            }

            salBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratific;

            if (salBruto > 7000 && producao >= 150 && gratific > 0)
            {
                MessageBox.Show($"O salário bruto é: R$ {salBruto.ToString("N2")}");
            }
            else
            {
                MessageBox.Show("O salário bruto é R$ 7000,00");
            }
        }

        private void txtProducao_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Valor inválido");
                e.Cancel = true;
            }
            else if (producao <= 0)
            {
                MessageBox.Show("Valor da produção deve ser maior que 0");
                e.Cancel = true;
            }
        }
    }
}
