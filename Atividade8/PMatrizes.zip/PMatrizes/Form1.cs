﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; //colocar manualmente dps de ir em Projeto >> adc referencias >> Microsoft.VisualBasic
using System.Collections;  //colocar manualmente

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";   // cria uma variável auxiliar pra receber o conteudo do inputbox (scanf)
            //string saída = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º número", "Entrada de dados"); // "label" e título da caixinha q vai aparecer

                if (!int.TryParse(auxiliar, out vetor[i])) // validação pra ver se é um numero inteiro
                {
                    MessageBox.Show("Número inválido");
                    i--;      // decrementa pra pessoa digitar dnv
                }

                //else
                //{
                //saída = auxiliar + "/n" + saída;
                //}

            }

            Array.Reverse(vetor); // inverte o vetor
            auxiliar = "";

            foreach (int x in vetor)
            {
                auxiliar += x + "\n"; //mostra os numeros que estão no vetor (o + "\n" é pra ele já incluir a quebra de linha)
            }

            //outra forma: 
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList minhaLista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro" }; //cria uma lista dinâmica

            minhaLista.Remove("Ótávio"); //remover o Otávio da lista >> método da lista dinâmica

            string auxiliar = "";
            foreach (string nomes in minhaLista)
            {
                auxiliar += nomes + "\n";   // mostra os nomes em forma de lista
            }

            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20,3]; //cria uma matriz bidimensional de 20 linhas e 3 colunas
            string auxiliar = "";
            double media = 0;

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Informe a {nota+1}º nota", "Médias");
                    if (!Double.TryParse(auxiliar, out notas[aluno, nota]) ||
                        notas[aluno, nota] < 0 ||
                        notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Valor inválido");
                        nota--;
                    }

                    else
                    {
                        media += notas[aluno, nota];
                    }
                }
                media = media / 3;
                MessageBox.Show ($"Média do aluno {aluno+1}: {media}");
                media = 0;
            }
            
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmEx4 obj4 = new frmEx4();
            obj4.Show(); //mostrar o formulario 4
        }
    }
}
