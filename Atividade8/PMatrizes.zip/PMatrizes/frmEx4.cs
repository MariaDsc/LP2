﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void lstbxNomes_SelectedIndexChanged(object sender, EventArgs e)
        {
           // lstbxNomes.Add() >> adicionar os nomes no listBox
    }
}
